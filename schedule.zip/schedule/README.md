# 일정 관리 사이트

1. Google 스프레드시트 생성
   - 시트 이름: Schedule
   - 컬럼: 차량 | 기사 | 예약자 | 장소 | 시작일 | 종료일 | 휴가여부

2. Google Apps Script 작성
   - Apps Script 코드를 붙여넣고 웹앱 배포 → Anyone
   - 발급 URL을 index.html SCRIPT_URL에 입력

3. GitHub Pages 배포
   - 이 폴더를 GitHub 레포에 업로드
   - Settings → Pages → Branch: main → Save
   - https://USERNAME.github.io/schedule-site/ 접속
